package kosmos.uiToolbox;

public class UITexture {

}
