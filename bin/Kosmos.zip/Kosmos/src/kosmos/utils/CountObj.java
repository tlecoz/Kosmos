package kosmos.utils;

public class CountObj {
	public int id;
	public CountObj(){
		id = 0;
	}
}
