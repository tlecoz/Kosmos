package kosmos.utils.cubeTree;

public interface ICubeTreePoint {

}
