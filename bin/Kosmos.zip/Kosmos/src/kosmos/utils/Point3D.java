package kosmos.utils;

public class Point3D {
	public float x;
	public float y;
	public float z;
	public int id;
	protected Point3D(){
		x = y = z = id = 0;
	}
}
