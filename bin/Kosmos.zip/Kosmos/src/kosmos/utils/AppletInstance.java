package kosmos.utils;

import processing.core.PApplet;

public class AppletInstance {
	
	public static PApplet applet;
	
	public AppletInstance(PApplet a){
		applet = a;
	}
	
}
