package kosmos.utils.texturePacker;

import java.util.ArrayList;
import java.util.Collections;

import kosmos.texture.TextureArea;
import kosmos.uiToolbox.textures.ComposedTextureObj;
import kosmos.uiToolbox.textures.RoundRectTextureObj;
import processing.core.PImage;

public class TexturePacker extends PImage {
	
	
	ArrayList<TextureArea> subTextures;
	
	public TexturePacker(int w, int h){
		super(w,h,2);
		subTextures = new ArrayList<TextureArea>();
	}
	
	public TextureArea addSubTexture(PImage img) {
		TextureArea t = new TextureArea(this,img);
		subTextures.add(t);
		return t;
	}
	public TextureArea addSubTexture(TextureArea area){
		subTextures.add(area);
		return area;
	}
	public ComposedTextureObj addSubTexture(ComposedTextureObj o){
		
		TextureArea[] areas = o.getAreas();
		int i,len = areas.length;
		TextureArea a;
		for(i=0;i<len;i++){
			a = areas[i];
			a.setMainTexture(this);
			subTextures.add(areas[i]);
		}
		
		return o;
	}
	
	public void drawElementsAndGetCorrectUV(){
		
		
		int i,len = subTextures.size();
		
		for(i=0;i<len;i++) subTextures.get(i).compareData = subTextures.get(i).w;
		Collections.sort(subTextures);
		
		for(i=0;i<len;i++) subTextures.get(i).compareData = subTextures.get(i).h;
		Collections.sort(subTextures);
		
		
		boolean multiLine = false;
		
		ArrayList<TextureArea> rest = new ArrayList<TextureArea>();
		ArrayList<TextureArea> a = subTextures;
		
		rest.add(subTextures.get(0));
		
		int sizeX = width;
		int sizeY = height;
		int px = 0,py = 0;
		int iY = 0;
		TextureArea t;
		
		
		while(rest.size() > 0 && a.size() > 0){
			rest = new ArrayList<TextureArea>();
			px = 0;
			py += iY;
			iY = a.get(0).h;
			
			for(i=0;i<len;i++){
				t = a.get(i);
				if(px + t.w > sizeX){
					multiLine = true;
					rest.add(t);
				}else{
					t.x = px;
					t.y = py;
					t.drawTemporaryOnTexture();
					px += t.w;
				}
			}
			
			a = rest;
			len = a.size();
			
		}
	}
	
	
}
