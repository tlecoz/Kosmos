package kosmos.utils.texturePacker;

public class TexturePackerRect {
	
	int x;
	int y;
	int w;
	int h;
	
	TexturePackerRect(int px,int py,int pw,int ph){
		x = px;
		y = py;
		w = pw;
		h = ph;
	}
	
}
