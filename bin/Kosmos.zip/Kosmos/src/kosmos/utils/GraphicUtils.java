package kosmos.utils;

import processing.core.PApplet;
import processing.core.PGraphics;
import processing.core.PImage;

public class GraphicUtils extends Object{
	
	static private PGraphics g;
	
	
	public GraphicUtils(PApplet applet){
		
		if(g == null){
			g = applet.createGraphics(applet.width, applet.height,applet.P2D);
		}
		
	}
	
	public static PGraphics getGraphics(){
		return g;
	}
	
	public static PImage getImage(int srcX,int srcY,int srcW,int srcH,int destX,int destY,int destW,int destH){
		
		PImage img = new PImage(destW,destH,2);
		img.copy(g,srcX, srcY, srcW, srcH, destX, destY, destW, destH);
		return img;
	}

	
}
