package kosmos.texture;

import processing.core.PImage;

public class TextureArea implements Comparable{
	  
	 public int x;
	 public int y;
	 public int w;
	 public int h;
	 public float minX;
	 public float minY;
	 public float maxX;
	 public float maxY;
	 
	 public int compareData;
	 
	 protected PImage textureImage;
	 public PImage temporaryImage;
	 
	 
	 public TextureArea(PImage textureImg,int px,int py,int pw,int ph){
	   
	   textureImage = textureImg;
	   
	   x = px;
	   y = py;
	   w = pw;
	   h = ph;
	   
	   minX = (float) (x);
	   minY = (float) (y);
	   maxX = (float) (x + w);
	   maxY = (float) (y + h);
	 }
	 
	 
	 
	 
	 public TextureArea(PImage textureImg){
		 x = y = w = h = 0;
		 minX = maxX = minY = maxY = 0.0f;
		 textureImage = textureImg;
	 }
	 public TextureArea(int pw,int ph){
		 x = y = 0;
		 w = pw; 
		 h = ph;
		 minX = maxX = minY = maxY = 0.0f;
		 //textureImage = textureImg;
	 }
	 public TextureArea(PImage textureImg,PImage temporaryImg){
		 x = y = 0; 
		 w = temporaryImg.width; 
		 h = temporaryImg.height;
		 minX = maxX = minY = maxY = 0.0f;
		 textureImage = textureImg;
		 temporaryImage = temporaryImg;
	 }
	 public TextureArea(PImage textureImg,int pw,int ph){
		 textureImage = textureImg;
		 w = pw;
		 h = ph;
		 x = y = 0;
		 minX = maxX = minY = maxY = 0.0f;
	 }
	 
	 public void setMainTexture(PImage source){
		 textureImage = source;
	 }
	 
	 
	 
	 public void drawTemporaryOnTexture(){
		 update(temporaryImage);
		 minX = (float) (x+1);
		 minY = (float) (y+1);
		 maxX = (float) (x + w-2);
		 maxY = (float) (y + h-2);
		 
		
		 temporaryImage = null;
	 }
	 
	 
	 public TextureArea clone(){
		 TextureArea t = new TextureArea(textureImage,x,y,w,h);
		 t.temporaryImage = temporaryImage;
		 temporaryImage = null;
		 return t;
	 }
	 
	 public void update(PImage src){
	    if(src != null) textureImage.copy(src,0,0,src.width,src.height,x,y,w,h); 
	 }
	 
	 public void update(PImage src,Boolean useAlpha){
	    if(useAlpha == true){
	      textureImage.blend(src,0,0,src.width,src.height,x,y,w,h,1); 
	    }else{
	      textureImage.copy(src,0,0,src.width,src.height,x,y,w,h); 
	    }
	 }
	 public void update(PImage src,int srcX,int srcY,int srcW,int srcH,Boolean useAlpha){
	    if(useAlpha == true){
	      textureImage.blend(src,srcX,srcY,srcW,srcH,x,y,w,h,1); 
	    }else{
	      textureImage.copy(src,srcX,srcY,srcW,srcH,x,y,w,h); 
	    }
	 }
	 
	 public int compareTo(Object o){
		return ((TextureArea) o).compareData - compareData;
	}
	 
	 
	 
}

	


