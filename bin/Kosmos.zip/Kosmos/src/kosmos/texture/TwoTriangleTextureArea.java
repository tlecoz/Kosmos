package kosmos.texture;

public class TwoTriangleTextureArea extends TextureArea{
	
	public SingleTriangleTextureUv top;
	public SingleTriangleTextureUv bottom;
	
	
	
	
	public TwoTriangleTextureArea(int size){
		super(size,size);
		
		
	}
	
	protected void initObjects(){
		top = new SingleTriangleTextureUv();
		bottom = new SingleTriangleTextureUv();
	}
	
	
	public void drawTemporaryOnTexture(){
		 
	    super.drawTemporaryOnTexture();
		 
		top.initUV(minX, minY, maxX, minY, minX, maxY);
		bottom.initUV(maxX, minY, maxX, maxY, minX, maxY);
	}
}
