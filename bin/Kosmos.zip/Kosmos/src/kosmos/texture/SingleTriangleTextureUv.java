package kosmos.texture;

public class SingleTriangleTextureUv {
	
	public float u0;
	public float v0;
	public float u1;
	public float v1;
	public float u2;
	public float v2;
	
	
	public SingleTriangleTextureUv(){
		
	}
	
	void initUV(float x0,float y0,float x1,float y1,float x2,float y2){
		u0 = x0;
		v0 = y0;
		u1 = x1;
		v1 = y1;
		u2 = x2;
		v2 = y2;
	}
}
