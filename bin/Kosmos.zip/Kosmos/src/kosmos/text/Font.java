package kosmos.text;

import java.util.HashMap;

import kosmos.displayList.Layer3D;
import kosmos.displayList.displayObjects.TextCharacter;
import kosmos.texture.TextureArea;
import kosmos.texture.TwoTriangleTextureArea;
import kosmos.utils.AppletInstance;
import kosmos.utils.GraphicUtils;
import processing.core.PApplet;
import processing.core.PGraphics;
import processing.core.PImage;
import processing.data.XML;

public class Font {
	
	
	private static Font defaultFont;
	
	private static HashMap<String,Font> fontByName = new HashMap<String,Font>(128);;
	
	private String name;
	
	HashMap<String,TextCharUv> uvByString;
	
	
	
	
	private float x0;
	private float y0;
	private float x1;
	private float y1;
	private float x2;
	private float y2;
	private float charSize;
	
	public Font(PApplet applet,String fontName){
		  
		  name = fontName;
		  
		  fontByName.put(name,this);
		  
		  XML xml = applet.loadXML(fontName+".xml");
		  
		  
		  
		  
		  int nbX = Integer.parseInt(xml.getString("nbX"));
		  int nbY = Integer.parseInt(xml.getString("nbY"));
		  int cellSize = Integer.parseInt(xml.getString("elementSize"));
		  charSize = Float.parseFloat(xml.getString("charSize"));
		  
		  computeTriangleVertexPosition();
		  
		  
		  XML[] children = xml.getChildren("char");
		  uvByString = new HashMap<String,TextCharUv>();
		  
		  
		  int i,j,len = children.length;
		  String[] charById = new String[children.length];
		  float[] widthById = new float[children.length];
		  float[] heightById = new float[children.length];
		  for (i = 0; i < len; i++)  {
			  charById[i] = "";
			  widthById[i] = 0;
			  heightById[i] = 0;
		  }
		  
		  for (i = 0; i < len; i++){
			  j = Integer.parseInt(children[i].getString("id"));
			  charById[j] = children[i].getContent();
			  widthById[j] = Float.parseFloat(children[i].getString("width"));
			  heightById[j] = Float.parseFloat(children[i].getString("height"));
		  }
		  
		  
		  PGraphics g = GraphicUtils.getGraphics();
		  g.setSize(cellSize*nbX, cellSize*nbY);
		  g.beginDraw();
		  g.background(0, 0);
		  g.tint(255);
		  g.image(applet.loadImage(fontName+".png"),0,0);
		  g.endDraw();
		  
		  TwoCharacterTextureArea[] charTextures = new TwoCharacterTextureArea[nbX*nbY];
		  int k = 0,charId = 0;
		  TwoCharacterTextureArea t;
		  
		  for (i = 0; i < nbY; i++){
			  for (j = 0; j < nbX; j++){
				  charTextures[k++] = t = new TwoCharacterTextureArea(cellSize,charById[charId],charById[charId+1],widthById[charId],heightById[charId],widthById[charId+1],heightById[charId+1]);
				  t.temporaryImage = GraphicUtils.getImage(j*cellSize, i*cellSize, cellSize, cellSize, 0, 0, cellSize, cellSize);
				  
				  uvByString.put(charById[charId++], (TextCharUv) t.top);
				  uvByString.put(charById[charId++], (TextCharUv) t.bottom);
			  }
		  }  
		  
		  g.background(0, 0);
	}
	
	public TextCharUv getUvByName(String n){
		return uvByString.get(n);
	}
	
	public static Font getDefaultFont(){
		if(defaultFont == null) defaultFont = new Font(AppletInstance.applet,"Arial");
		return defaultFont;
	}
	public static Font getFontByName(String n){
		return fontByName.get(n);
	}
	public static boolean fontExists(String fontName){
		int i,len = fontByName.size();
		for(i=0;i<len;i++) if(fontByName.get(i).getFontName() == fontName) return true;
		return false;
	}
	
	public float getCharSize(){
		return charSize;
	}
	
	public String getFontName(){
		return name;
	}
	
	private void computeTriangleVertexPosition(){
		  float halfCharSize = charSize / 2.0f;
		  float charSizeAndHalf = charSize * 1.5f;
		  
		  float angle = (float) (Math.PI*1.75f);
		  float offX = (float) (Math.cos(angle) * charSizeAndHalf);
		  float offY = (float) (Math.sin(angle) * charSizeAndHalf);
		  angle -= Math.PI / 2;
		  offX += Math.cos(angle) * halfCharSize;
		  offY += Math.sin(angle) * halfCharSize;
		  
		 
		  x0 = (offX) * charSize;
	      y0 = (offY) * charSize;
	      x1 = (offX+1) * charSize;
	      y1 = (offY+1) * charSize;
	      x2 = (offX) * charSize;
	      y2 = (offY+1) * charSize;
		  
		  
	      float a = (float) (Math.atan2(y0,x0) + angle);
	      float d = (float) Math.sqrt(x0 * x0 + y0 * y0);
	      
	      x0 = (float) (Math.cos(a) * d);
	      y0 = (float) (Math.sin(a) * d);
	      
	      a = (float) (Math.atan2(y1, x1) + angle);
		  d = (float) (Math.sqrt(x1 * x1 + y1 * y1));
		  x1 = (float) (Math.cos(a) * d);
	      y1 = (float) (Math.sin(a) * d);
	      
	      a = (float) (Math.atan2(y2, x2) + angle);
		  d = (float) (Math.sqrt(x2 * x2 + y2 * y2));
		  x2 = (float) (Math.cos(a) * d);
	      y2 = (float) (Math.sin(a) * d);
	}
	
	
	
	public TextCharacter createTextCharacterInstance(Layer3D layer,String charString, float posx,float posy,float scale){
		
		return new TextCharacter(layer,uvByString.get(charString),posx,posy,scale,x0,y0,x1,y1,x2,y2);
		
	}
	
	
}
