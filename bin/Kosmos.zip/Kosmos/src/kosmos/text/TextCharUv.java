package kosmos.text;

import kosmos.texture.SingleTriangleTextureUv;

public class TextCharUv extends SingleTriangleTextureUv{
	
	public float w;
	public float h;
	public String value;
	public TwoCharacterTextureArea texture;
	
	public TextCharUv(TwoCharacterTextureArea charTexture,String charText,float charWidth,float charHeight){
		super();
		value = charText;
		w = charWidth;
		h = charHeight;
		texture = charTexture;
	}

}
