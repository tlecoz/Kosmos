package kosmos.text;

import kosmos.texture.TwoTriangleTextureArea;

public class TwoCharacterTextureArea extends TwoTriangleTextureArea {
	
	TwoCharacterTextureArea(int size,String topText,String bottomText,float topW,float topH,float bottomW,float bottomH){
		super(size);
		top = new TextCharUv(this,topText,topW,topH);
		bottom = new TextCharUv(this,bottomText,bottomW,bottomH);
	}
	
	protected void initObjects(){ }
}
