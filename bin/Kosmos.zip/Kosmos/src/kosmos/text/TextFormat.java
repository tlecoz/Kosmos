package kosmos.text;

import kosmos.events.EventDispatcher3D;

public class TextFormat extends EventDispatcher3D {
	
	public static final int FONT_CHANGED = 0;
	public static final int TEXTSIZE_CHANGED = 1;
	public static final int COLOR_CHANGED = 2;
	public static final int LETTERSPACING_CHANGED = 3;
	public static final int LINESPACING_CHANGED = 4;
	public static final int BOLD_CHANGED = 5;
	public static final int ITALIC_CHANGED = 6;
	
	
	private static TextFormat defaultTextFormat;
	
	private float size;
	private int color;
	private int r;
	private int g;
	private int b;
	private int a;
	private float letterSpacing;
	private float lineSpacing;
	private boolean bold;
	private boolean italic;
	private Font font;
	
	
	TextFormat(Font textFont,int textColor,float textSize, float letterSpace,float lineSpace,boolean useBold,boolean useItalic){
		super();
		
		size = textSize;
		color = textColor;
		letterSpacing = letterSpace;
		lineSpacing = lineSpace;
		bold = useBold;
		italic = useItalic;
		
		a = color >>> 24;
		r = color >>> 16 & 0xFF;
		g = color >>>  8 & 0xFF;
		b = color & 0xFF;
		
	}
	
	TextFormat(Font textFont,int textColor,float textSize, float letterSpace,float lineSpace){
		super();
		
		size = textSize;
		color = textColor;
		letterSpacing = letterSpace;
		lineSpacing = lineSpace;
		bold = false;
		italic = false;
		
		a = color >>> 24;
		r = color >>> 16 & 0xFF;
		g = color >>>  8 & 0xFF;
		b = color & 0xFF;
	}
	
	TextFormat(Font textFont,int textColor,float textSize){
		super();
		
		size = textSize;
		color = textColor;
		letterSpacing = 0;
		lineSpacing = 0;
		bold = false;
		italic = false;
		
		a = color >>> 24;
		r = color >>> 16 & 0xFF;
		g = color >>>  8 & 0xFF;
		b = color & 0xFF;
	}
	
	
	public static TextFormat getDefaultTextFormat(){
		if(defaultTextFormat == null){
			defaultTextFormat = new TextFormat(Font.getDefaultFont(),0,20,0,0,false,false);
		}
		return defaultTextFormat;
	}
	
	
	public Font getFont(){ return font;};
	public float getTextSize(){ return size;};
	public int getColor(){ return color;};
	public int getRed(){ return r;};
	public int getGreen(){ return g;};
	public int getBlue(){ return b;};
	public int getAlpha(){ return a;};
	public float getLetterSpacing(){ return letterSpacing;};
	public float getLineSpacing(){ return lineSpacing;};
	public boolean getBold(){ return bold;};
	public boolean getItalic(){ return italic;};
	
	
	

	
	public void setFont(Font n){
		if(font != n){
			font = n;
			dispatchEvent(""+FONT_CHANGED);
		}
	}
	public void setTextSize(float n){
		if(size != n){
			size = n;
			dispatchEvent(""+TEXTSIZE_CHANGED);
		}
	}
	public void setColor(int n){ 
		if(color != n){
			color = n;
			dispatchEvent(""+COLOR_CHANGED);
		}
	}
	public void setRed(int n){
		if(r != n){
			r = n;
			dispatchEvent(""+COLOR_CHANGED);
		}
	}
	public void setGreen(int n){
		if(g != n){
			g = n;
			dispatchEvent(""+COLOR_CHANGED);
		}
	}
	public void setBlue(int n){
		if(b != n){
			b = n;
			dispatchEvent(""+COLOR_CHANGED);
		}
	}
	public void setAlpha(int n){
		if(a != n){
			a = n;
			dispatchEvent(""+COLOR_CHANGED);
		}
	}
	public void setLetterSpacing(float n){
		if(letterSpacing != n){
			letterSpacing = n;
			dispatchEvent(""+LETTERSPACING_CHANGED);
		}
	}
	public void setLineSpacing(float n){
		if(lineSpacing != n){
			lineSpacing = n;
			dispatchEvent(""+LINESPACING_CHANGED);
		}
	}
	public void setBold(boolean n){
		if(bold != n){
			bold = n;
			dispatchEvent(""+BOLD_CHANGED);
		}
	}
	public void setItalic(boolean n){
		if(italic != n){
			italic = n;
			dispatchEvent(""+ITALIC_CHANGED);
		}	
	}
	
}
