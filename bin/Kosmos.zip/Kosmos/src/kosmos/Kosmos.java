package kosmos;

import kosmos.examples.Example01;
import kosmos.examples.Example02;
import kosmos.examples.Example03;
import processing.core.PApplet;


public class Kosmos extends PApplet {

	Example03 example;

	
	public void setup(){ 
		size(1000,1000,P3D);
		example = new Example03(this);
	} 
	 
	public void draw(){ 
		background(0);
		example.update();
	} 
}
