package kosmos.displayList;

import kosmos.utils.CountObj;
import processing.core.PApplet;

public class TriangleObj implements Comparable {
	 
	 private int i0x2;
	 private int i1x2;
	 private int i2x2;
	 
	 private int i0y2;
	 private int i1y2;
	 private int i2y2;

	 private int i0x3;
	 private int i1x3;
	 private int i2x3;
	 
	 private int i0y3;
	 private int i1y3;
	 private int i2y3;
	 
	 private int i0z3;
	 private int i1z3;
	 private int i2z3;
	 
	 private float[] allTransformXYZ;
	 private float[] allVertexUV;
	 private float[] allXYUV;
	 
	 
	 private PApplet applet;
	 
	 public int z;
	 public Shape3D obj;
	 public Boolean visible;
	 private Boolean renderable;
	 
	 protected CountObj countObj;
	 
	 private float minimalZ;
	 
	 TriangleObj(PApplet appletObj,Shape3D target,int _i0,int _i1,int _i2,float[] _allTransformXYZ,float[] _allVertexUV,float[] _allXYZUV,CountObj countObject){
	  
	  applet = appletObj;
		 
	  countObj = countObject;
	  
	  
	  i0x2 = _i0 * 2;
	  i1x2 = _i1 * 2;
	  i2x2 = _i2 * 2; 
	   
	  i0y2 = _i0 * 2 + 1;
	  i1y2 = _i1 * 2 + 1;
	  i2y2 = _i2 * 2 + 1;  
	   
	  i0x3 = _i0 * 3;
	  i1x3 = _i1 * 3;
	  i2x3 = _i2 * 3; 
	   
	  i0y3 = _i0 * 3 + 1;
	  i1y3 = _i1 * 3 + 1;
	  i2y3 = _i2 * 3 + 1; 
	   
	  i0z3 = _i0 * 3 + 2;
	  i1z3 = _i1 * 3 + 2;
	  i2z3 = _i2 * 3 + 2;
	  
	  visible = renderable = true;
	  
	  obj = target;
	  allTransformXYZ = _allTransformXYZ;
	  allVertexUV = _allVertexUV;
	  allXYUV = _allXYZUV;
	  
	  //System.out.println(obj.renderer.focalLength+" + "+obj.renderer.root.z);
	  
	  minimalZ = (float) (obj.renderer.focalLength*1.6 + obj.renderer.camera.z)*3;
	  
	 } 
	 
	 public void updateZ(){
	   renderable = obj.renderable();
	   if(visible && renderable){
		   z =  (int) ((allTransformXYZ[i0z3] + allTransformXYZ[i1z3] + allTransformXYZ[i2z3])) ;
		   renderable = z < minimalZ;
		   z *= 333.333;
	   }
	 }
	 
	 /*
	 public void drawTriangle2(){
		 if(visible == false || renderable == false) return ;
		 
		 int n = countObj.id;
		 int id = n * 5;
		 allXYUV[id++] = allTransformXYZ[i0x3];
		 allXYUV[id++] = allTransformXYZ[i0y3];
		 //allXYUV[id++] = n++ * 0.001f;
		 allXYUV[id++] = allVertexUV[i0x2];
		 allXYUV[id++] = allVertexUV[i0y2];
		 
		 allXYUV[id++] = allTransformXYZ[i1x3];
		 allXYUV[id++] = allTransformXYZ[i1y3];
		 //allXYUV[id++] = n++ * 0.001f;
		 allXYUV[id++] = allVertexUV[i1x2];
		 allXYUV[id++] = allVertexUV[i1y2];
		 
		 allXYUV[id++] = allTransformXYZ[i2x3];
		 allXYUV[id++] = allTransformXYZ[i2y3];
		 //allXYUV[id++] = n++ * 0.001f;
		 allXYUV[id++] = allVertexUV[i2x2];
		 allXYUV[id++] = allVertexUV[i2y2];
		 
		 countObj.id += 3;
		 
	 }
	 */
	 
	 public DisplayObject3D drawTriangle(DisplayObject3D currentDrawObj){ 
		 
		 if(renderable == false || visible == false) return currentDrawObj;
		 
		 obj.____applyColorTransform(currentDrawObj);
		 
	     applet.vertex(allTransformXYZ[i0x3],allTransformXYZ[i0y3],allVertexUV[i0x2],allVertexUV[i0y2]);
	     applet.vertex(allTransformXYZ[i1x3],allTransformXYZ[i1y3],allVertexUV[i1x2],allVertexUV[i1y2]);
	     applet.vertex(allTransformXYZ[i2x3],allTransformXYZ[i2y3],allVertexUV[i2x2],allVertexUV[i2y2]);
	     
	     
	     
	     return obj;
	 }
	 
	 /*
	 boolean drawTriangleAndCheckMouseIfMouseIsOver(float mouseX,float mouseY){
		 if(visible == false || renderable == false) return false;
		 
		 
		 applet.vertex(allTransformXYZ[i0x3],allTransformXYZ[i0y3],allVertexUV[i0x2],allVertexUV[i0y2]);
		 applet.vertex(allTransformXYZ[i1x3],allTransformXYZ[i1y3],allVertexUV[i1x2],allVertexUV[i1y2]);
		 applet.vertex(allTransformXYZ[i2x3],allTransformXYZ[i2y3],allVertexUV[i2x2],allVertexUV[i2y2]);
		 
		 return hitTest(mouseX,mouseY);
		 
	 }
	 */
	 
	 Boolean hitTest(float posx,float posy){
	    
	    if(visible == false) return false;
	    
	    float p1x = allTransformXYZ[i0x3];
	    float p1y = allTransformXYZ[i0y3];
	    float p2x = allTransformXYZ[i1x3];
	    float p2y = allTransformXYZ[i1y3];
	    float p3x = allTransformXYZ[i2x3];
	    float p3y = allTransformXYZ[i2y3];
	 
	    float d1 =  p1x * (p2y - posy) + p2x * (posy - p1y) + posx * (p1y - p2y);
	    float d2 =  p2x * (p3y - posy) + p3x * (posy - p2y) + posx * (p2y - p3y);
	    float d3 =  p3x * (p1y - posy) + p1x * (posy - p3y) + posx * (p3y - p1y);
	 
	    if ((d1 > 0 && d2 > 0 && d3 > 0) || (d1 < 0 && d2 < 0 && d3 < 0)) {
	      return true;
	    }
	    
	    return false;
	 }
	  
	  
	 public int compareTo(Object o){
	  return z-((TriangleObj) o).z ; 
	 }
	 
	 
	 
	}
