package kosmos.displayList;

import java.util.ArrayList;
import java.util.Collections;

import kosmos.text.Font;
import kosmos.texture.TextureArea;
import kosmos.uiToolbox.textures.ComposedTextureObj;
import kosmos.utils.CountObj;
import kosmos.utils.texturePacker.TexturePacker;
import processing.core.PApplet;
import processing.core.PImage;

public class Layer3D extends Sprite3D {
	  
	 
	  protected TexturePacker texturePacker;
	  
	  public PApplet applet;
	  public Sprite3D camera;
	  public Shape3D objectUnderMouse;
	  
	  public int nbTriangle;
	  public int nbVertex;
	  public int nbVertexVisible;
	  public int nbObject;
	  
	  protected CountObj countObj; 
	  
	  public float[] allVertexXYZ;
	  public float[] allVertexUV;
	  public float[] allTransformXYZ;
	  public float[] allXYUV;
	  public TriangleObj[] allTriangles;
	  
	  protected ArrayList<TriangleObj> triangleList;
	  
	  public float stageW;
	  public float stageH;
	  public float halfStageW;
	  public float halfStageH;
	  
	  public float focalLength;
	  public float fieldOfView;
	  
	  
	  private boolean checkMouseEvent;
	  private boolean mouseIsPressed;
	  private Shape3D pressedObject;
	  
	  
	  
	  
	  
	  
	  public Layer3D(PApplet appletObj,float screenWidth,float screenHeight,int textureWidth,int textureHeight,int nbTriangleMax,boolean useMouseEvent){
	    super();
	    
	    
	    applet = appletObj;
	    
	    checkMouseEvent = useMouseEvent;
	    mouseIsPressed = false;
	    applet.hint(applet.DISABLE_DEPTH_TEST);
	    
	    setRenderDimension(screenWidth,screenHeight);
	    
	    //textureW = textureWidth;
	    //textureH = textureHeight;
	    texturePacker = new TexturePacker(textureWidth,textureHeight);
	    
	    initBuffers(nbTriangleMax); 
	  }
	  public Layer3D(PApplet appletObj,int textureWidth,int textureHeight,int nbTriangleMax,boolean useMouseEvent){
	    super();
	    
	    applet = appletObj;
	    
	    checkMouseEvent = useMouseEvent;
	    mouseIsPressed = false;
	    applet.hint(applet.DISABLE_DEPTH_TEST);
	    
	    setRenderDimension(applet.width,applet.height);
	    
	    texturePacker = new TexturePacker(textureWidth,textureHeight);
	    
	    initBuffers(nbTriangleMax); 
	  }
	  
	  public Layer3D(PApplet appletObj,int textureWidth,int textureHeight,boolean useMouseEvent){
	    super();
	    
	    applet = appletObj;
	    checkMouseEvent = useMouseEvent;
	    mouseIsPressed = false;
	    applet.hint(applet.DISABLE_DEPTH_TEST);
	    
	    setRenderDimension(applet.width,applet.height);
	    
	    texturePacker = new TexturePacker(textureWidth,textureHeight);
	    
	    initBuffers(5000); 
	  }
	  
	  public Layer3D(PApplet appletObj,int textureWidth,int textureHeight){
	    super();
	    
	    applet = appletObj;
	    checkMouseEvent = true;
	    mouseIsPressed = false;
	    applet.hint(applet.DISABLE_DEPTH_TEST);
	    
	    setRenderDimension(applet.width,applet.height);
	    
	    texturePacker = new TexturePacker(textureWidth,textureHeight);
	    
	    initBuffers(5000); 
	  }
	  
	  
	  public Font addFont(String fontName){
		  if(Font.fontExists(fontName)) return Font.getFontByName(fontName);
		  return new Font(applet,fontName);
	  }
	  
	  public TextureArea addTextureImage(PImage img){
		  return texturePacker.addSubTexture(img);
	  }
	  public ComposedTextureObj addTextureImage(ComposedTextureObj o){
		  return texturePacker.addSubTexture(o);
	  }
	  public TextureArea addTextureImage(TextureArea area){
		  return texturePacker.addSubTexture(area);
	  }
	  
	  public void packTextures(){
		  texturePacker.drawElementsAndGetCorrectUV();
	  }
	  
	  
	  
	  public DisplayObject3D appendObject(DisplayObject3D o){
	    return camera.appendObject(o);
	  }
	  
	  public Object3D removeObject(Object3D o){
	    return camera.removeObject(o);
	  }
	  
	  
	  
	  
	  protected void setRenderDimension(float screenWidth,float screenHeight){
	    stageW = screenWidth;
	    stageH = screenHeight;
	    _realX = halfStageW = (float) (stageW / 2.0);
	    _realY = halfStageH = (float) (stageH / 2.0);
	    
	    fieldOfView = (float) (Math.PI/180.0 * 60.0);
	    focalLength = (float) (halfStageW * (Math.cos(fieldOfView/2.0) / Math.sin(fieldOfView/2.0)));
	    _realZ = 0;//focalLength;
	    
	    setStage(this);
	    //println("focalLength = "+focalLength);
	  }
	  

	  protected void initBuffers(int nbTriangleMax){
	    int nbVertexMax = nbTriangleMax * 3;
	    
	    countObj = new CountObj();
	    
	    nbTriangle = nbVertex = nbVertexVisible = 0;
	    
	    allTriangles = new TriangleObj[nbTriangleMax];
	    triangleList = new ArrayList<TriangleObj>();
	    
	    allVertexXYZ = new float[nbVertexMax*3];
	    allVertexUV = new float[nbVertexMax*2];
	    allTransformXYZ = new float[nbVertexMax*3];
	    //allXYUV = new float[nbVertexMax * 4];
	    
	    //texturePacker = applet.createImage(textureW,textureH,applet.ARGB);
	    //texturePacker.loadPixels();
	    
	    camera = new Sprite3D();
	    camera.x = 0;
	    camera.y = 0;
	    camera.z = (float) (-focalLength*1.00001);
	    super.appendObject(camera);
	    
	  }
	  /*
	  public TextureArea defineNewTextureArea(int px,int py,PImage img,Boolean useAlpha){
	     TextureArea t = new TextureArea(texturePacker,px,py,img.width,img.height);
	     t.update(img,useAlpha); 
	     return t;
	  }
	  */
	  
	  public int getNewVertex(float px,float py,float pz,float u,float v){
	    int vertexId =  nbVertex++;
	    int v3 = vertexId * 3;
	    int v2 = vertexId * 2;
	    allVertexXYZ[v3] = allTransformXYZ[v3] = px;
	    allVertexXYZ[v3+1] = allTransformXYZ[v3+1] = py;
	    allVertexXYZ[v3+2] = allTransformXYZ[v3+2] = pz;
	    
	    allVertexUV[v2] = u;
	    allVertexUV[v2+1] = v;
	    
	    return vertexId;
	  }
	  
	  public void addNewTriangle(Shape3D o,int i0,int i1,int i2){
	    TriangleObj t = new TriangleObj(applet,o,i0,i1,i2,allTransformXYZ,allVertexUV,allXYUV,countObj);
	    triangleList.add(t);
	    allTriangles[nbTriangle++] = t;
	  }
	  
	  
	  private void applyMouseAction(){
		  if(applet.mousePressed != mouseIsPressed){
				mouseIsPressed = applet.mousePressed;
				if(mouseIsPressed){
					if(objectUnderMouse != null){
						objectUnderMouse.mousePressed();
						pressedObject = objectUnderMouse;
					}
				}else{
					if(objectUnderMouse != null){
					    if(pressedObject != null){
					    	pressedObject.mouseReleased();
					    	if(pressedObject == objectUnderMouse){
					    		pressedObject.mouseClick();
					    	}
					    }else{
					    	objectUnderMouse.mouseReleased();
					    }
					}else{
						if(pressedObject != null){
					    	pressedObject.mouseReleased();
					    }
					}
					
				}
			}
	  }
	  
	  
	  
	  private Shape3D updateAll(boolean enableMouseEvent){
		  
		  if(checkMouseEvent && enableMouseEvent) applyMouseAction();
		  
			//camera.updatePosition();
			//camera.updateVertexPosition();
		    
		    int i,len = children.size();
		    for(i=0;i<len;i++)children.get(i).updatePosition();
		    
		    updateVertexPosition();
		    
		    for(i=0;i<nbTriangle;i++) allTriangles[i].updateZ();
		    
		    Collections.sort(triangleList);
		    
		    
		    
		    applet.beginShape(applet.TRIANGLES);
		    applet.noStroke();
		    applet.noSmooth();
		    applet.texture(texturePacker);
		    
		    String c = "";
		    
		    int k = 0;
		    TriangleObj t;
		    Shape3D mc;
		    Boolean checkMouse = true;
		    
		    
		    
		    if(checkMouseEvent && enableMouseEvent){
			    for(i=0;i<nbTriangle;i++){
			       t = triangleList.get(i);
				    
			       if(t.hitTest(applet.mouseX , applet.mouseY ) == true ){
			    	  if(objectUnderMouse != t.obj){
			    		  if(objectUnderMouse != null) objectUnderMouse.setMouseIsOver(false);
			    	   	  objectUnderMouse = t.obj;
			    		  objectUnderMouse.setMouseIsOver(true);
			    	  }
			    	  checkMouse = false;
			    	  break;
			       }
			    }
			    
			    if(checkMouse == true){
			    	if(objectUnderMouse != null){
			    		objectUnderMouse.setMouseIsOver(false);
			    		objectUnderMouse = null;
			    	}
			    }
		    }
		    
		    //k = 0;
		    DisplayObject3D o = null;
		    for(i=nbTriangle-1;i>-1;i--) {
		    	o = triangleList.get(i).drawTriangle(o);
		    }
		    
		    //System.out.println("K = "+k);
		    /*
		    countObj.id = 0;
		    for(i=nbTriangle-1;i>-1;i--)   triangleList.get(i).drawTriangle2();
		    float[] v = new float[countObj.id * 5];
		    System.arraycopy(allXYUV,0,v,0,countObj.id * 5);
		    applet.vertex(v);
		    */
		    
		    
		    
		    applet.endShape();
		    
		    
		    
		    return objectUnderMouse;
		    //applet.println(objectUnderMouse);
		  
		  
	  }
	  
	  public Shape3D update(){
		 return updateAll(true);
	  }
	  
	  public Shape3D update(boolean enableMouseEvent){
		 return updateAll(enableMouseEvent);
	  }
	  
	  
	  
	}

