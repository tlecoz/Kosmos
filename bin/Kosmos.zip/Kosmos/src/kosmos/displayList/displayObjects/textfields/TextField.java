package kosmos.displayList.displayObjects.textfields;

import java.util.ArrayList;

import kosmos.displayList.Sprite3D;
import kosmos.displayList.displayObjects.TextCharacter;
import kosmos.events.EventDispatcher3D;
import kosmos.events.IEventReceiver;
import kosmos.text.Font;
import kosmos.text.TextFormat;

public class TextField extends Sprite3D implements IEventReceiver{
	
	private TextFormat textFormat;
	private Font font;
	private float charSize;
	private float charScale;
	
	
	public String text;
	private String _text;
	
	private float textSize;
	private float letterSpacing;
	private float lineSpacing;
	private boolean italic;
	private boolean bold;
	
	private float textfieldW;
	private float textfieldH;
	
	
	TextField(float w,float h){
		super();
		textfieldW = w;
		textfieldH = h;
		text = _text = "";
		textFormat = TextFormat.getDefaultTextFormat();
		textFormat.addEventListener((IEventReceiver) this);
		applyTextFormat();
	}
	
	
	public float getTextfieldWidth(){ return textfieldW; }
	public float getTextfieldHeight(){ return textfieldH; }
	
	public void setTextfieldWidth(float n){ 
		textfieldW = n;
		updateCharacterPosition();
	}
	public void setTextfieldHeight(float n){
		textfieldH = n; 
		updateCharacterPosition();
	}
	
	
	public TextFormat getTextFormat(){
		return textFormat;
	}
	public void setTextFormat(TextFormat tf){
		if(tf != textFormat){
			textFormat = tf;
			applyTextFormat();
		}
	}
	
	private void applyTextFormat(){
		
		font = textFormat.getFont();
		changeTextSize();
		
		redMulti = textFormat.getRed();
		greenMulti = textFormat.getGreen();
		blueMulti = textFormat.getBlue();
		alpha = textFormat.getAlpha();
		
		letterSpacing = textFormat.getLetterSpacing();
		lineSpacing = textFormat.getLineSpacing();
		
		italic = textFormat.getItalic();
		bold = textFormat.getBold();
		
		applyBold();
		applyItalic();
		updateCharacterPosition();
		
	}
	
	private void changeTextSize(){
		charSize = font.getCharSize();
		textSize = textFormat.getTextSize();
		charScale = textSize / charSize; 
		
		int i,len = children.size();
		for(i=0;i<len;i++) ( (TextCharacter) children.get(i)).changeScale(charScale);
		
		updateCharacterPosition();
	}
	
	private void changeFont(){
		charSize = font.getCharSize();
		textSize = textFormat.getTextSize();
		charScale = textSize / charSize; 
		
		int i,len = children.size();
		for(i=0;i<len;i++) {
			( (TextCharacter) children.get(i)).changeFont(font, charScale);
		}
		
		updateCharacterPosition();
	}
	
	private void applyBold(){
		int i,len = children.size();
		for(i=0;i<len;i++) ( (TextCharacter) children.get(i)).bold(bold);
		updateCharacterPosition();
	}
	private void applyItalic(){
		int i,len = children.size();
		for(i=0;i<len;i++) ( (TextCharacter) children.get(i)).italic(italic);
	}
	
	
	
	private void updateCharacterPosition(){
		float px = 0,py = 0;
		int i,len = children.size();
		TextCharacter t;
		for(i=0;i<len;i++){
			t = (TextCharacter) children.get(i);
			//if(t.wt.x = px;
			
		}
	}
	
	
	
	
	public void applyEvent(String action, EventDispatcher3D obj){
		if(obj == textFormat){
			int eventID = Integer.parseInt(action);
			switch(eventID){
				case TextFormat.FONT_CHANGED:
					font = textFormat.getFont();
					changeFont();
					changeTextSize();
					break;
				case TextFormat.COLOR_CHANGED:
					redMulti = textFormat.getRed();
					greenMulti = textFormat.getGreen();
					blueMulti = textFormat.getBlue();
					alpha = textFormat.getAlpha();
					break;
				case TextFormat.TEXTSIZE_CHANGED:
					changeTextSize();
					break;
				case TextFormat.LETTERSPACING_CHANGED:
					letterSpacing = textFormat.getLetterSpacing();
					updateCharacterPosition();
					break;
				case TextFormat.LINESPACING_CHANGED:
					lineSpacing = textFormat.getLineSpacing();
					updateCharacterPosition();
					break;
				case TextFormat.BOLD_CHANGED:
					bold = textFormat.getBold();
					applyBold();
					break;
				case TextFormat.ITALIC_CHANGED:
					italic = textFormat.getItalic();
					applyItalic();
					break;
			} 
		}
	}
	
	
}
