package kosmos.displayList.displayObjects;

import kosmos.displayList.Layer3D;
import kosmos.displayList.Shape3D;
import kosmos.text.Font;
import kosmos.text.TextCharUv;
import kosmos.texture.TextureArea;


public class TextCharacter extends Shape3D {
	
	private TextCharUv charUv;
	private float boldScale;
	private float italicScale;
	private boolean applyBold;
	private boolean applyItalic;
	private float scale;
	
	private float charWidth;
	private float charHeight;
	
	
	
	public TextCharacter(Layer3D renderer,TextCharUv uvChar,float posx,float posy,float scale,float x0,float y0,float x1,float y1,float x2,float y2){
	    
	    super(renderer,uvChar.texture,1);
	    
	    int i0 = renderer.getNewVertex(x0,y0,0,uvChar.u0,uvChar.v0);
	    int i1 = renderer.getNewVertex(x1,y1,0,uvChar.u1,uvChar.v1);
	    int i2 = renderer.getNewVertex(x2,y2,0,uvChar.u2,uvChar.v2);
	    
	    renderer.addNewTriangle(this,i0,i1,i2);
	    
	    nbVertex = 3;
	    startVertexId = i0;
	    
	    x = posx;
	    y = posy;
	    z = 0.0f;
	    
	    charUv = uvChar;
	    charWidth = charUv.w;
	    charHeight = charUv.h;
	    
	    boldScale = 1.1f;
	    italicScale = 1.1f;
	    
	    applyBold = false;
	    applyItalic = false;
	    
	    changeScale(scale);
	}
	
	
	public void changeFont(Font f,float scale){
		charUv = f.getUvByName(charUv.value);
	    charWidth = charUv.w;
	    charHeight = charUv.h;
	    
	    changeScale(scale);
	    updateCharacterTexture();
	}
	public void changeScale(float s){
		scale = s;
		if(false == applyBold) scaleX = scaleY = scaleZ = scale;
		else scaleX = scaleY = scaleZ = scale * boldScale;
	}
	
	
	public float getCharWidth(){
		return charWidth;
	}
	public float getCharHeight(){
		return charHeight;
	}
	
	
	
	
	public void bold(boolean b){
		applyBold = b;
		changeScale(scale);
	}
	public void bold(boolean b,float boldScaleRatio){
		boldScale = boldScaleRatio;
		bold(b);
	}
	
	
	public void italic(boolean b){
		applyItalic = b;
		changeScale(scale);
	}
	public void italic(boolean b,float italicScaleRatio){
		italicScale = italicScaleRatio;
		italic(b);
	}
	
	
	
	public void updateCharacterTexture(){
		int id = startVertexId * 2;
		  
		allVertexUV[id++] = charUv.u0;
		allVertexUV[id++] = charUv.v0;
		  
		allVertexUV[id++] = charUv.u1;
		allVertexUV[id++] = charUv.v1;
		  
		allVertexUV[id++] = charUv.u2;
		allVertexUV[id++] = charUv.v2;
		  
	}
	
	
	
	
	
}
