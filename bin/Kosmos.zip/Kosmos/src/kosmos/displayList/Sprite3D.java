package kosmos.displayList;

import java.util.ArrayList;

public class Sprite3D extends DisplayObject3D {
	  
	 
	  
	  public ArrayList<Object3D> children;
	  
	  
	  
	  
	  
	  
	  public Sprite3D(){
	    super();
	    visible = true;
	    children = new ArrayList<Object3D>();
	    
	  }
	  
	  public DisplayObject3D appendObject(DisplayObject3D o){
	    children.add(o);
	    if(stage != null) o.setStage(stage);
	    o.setParent(this);
	    return o;
	  }
	  
	  public Object3D removeObject(Object3D o){
	    children.remove(children.lastIndexOf(o));
	    o.setParent(null);
	    o.setStage(null);
	    return o;
	  }
	  
	  public void setStage(Layer3D r){
	    super.setStage(r);
	    int i,len = children.size();
	    for(i=0;i<len;i++) children.get(i).setStage(r); 
	  }
	  
	  
	  
	  public void updatePosition(){
		  //_realX = parent._realX + x;
		  //_realY = parent._realY + y;
		  //_realZ = parent._realZ + z;
		     
		  _realSX = parent._realSX * scaleX;
		  _realSY = parent._realSY * scaleY;
		  _realSZ = parent._realSZ * scaleZ;
		    
		  _realRX = parent._realRX + rotationX;
		  _realRY = parent._realRY + rotationY;
		  _realRZ = parent._realRZ + rotationZ;
		  
		  _realRed = parent._realRed * redMulti;;
		  _realGreen = parent._realGreen * greenMulti;
		  _realBlue = parent._realBlue * blueMulti;
		  _realAlpha = parent._realAlpha * alpha;
		  
		  
		  
		  float px,py,pz,xy,xz,yz,yx,zx,zy;
	      float ppx,ppy,ppz;
	      
	      float psx = (float) Math.sin(_realRX);
	      float pcx = (float) Math.cos(_realRX);
	      
	      float psy = (float) Math.sin(_realRY);
	      float pcy = (float) Math.cos(_realRY);
	      
	      float psz = (float) Math.sin(_realRZ);
	      float pcz = (float) Math.cos(_realRZ);
	      
	      ppx = x;
	      ppy = y;
	      ppz = z;
	      
	      
	      float scaleFactor;
	      
	      //ROTATION X
	      xy = pcx * ppy - psx * ppz;
	      xz = psx * ppy + pcx * ppz;

	      //ROTATION Y
	      yz = pcy * xz - psy * ppx;
	      yx = psy * xz + pcy * ppx;

	      //ROTATION Z
	      zx = pcz*yx - psz*xy;
	      zy = psz*yx + pcz*xy;
	      
	      
	      scaleFactor = focalLength/(focalLength -parent._realZ+ yz);
	        
	      ppx = zx * scaleFactor;
	      ppy = zy * scaleFactor;
	      ppz = yz ;
	      
	      
	      
	      _realX = ppx + parent._realX;
	      _realY = ppy + parent._realY;
	      _realZ = ppz + parent._realZ;
		  
		  
		  //stage.applet.println(_realZ);
		  
		  
		  
		  
	    
	      int i,len = children.size();
	      for(i=0;i<len;i++)children.get(i).updatePosition();
	  }
	 
	  
	  public void updateVertexPosition(){
	    if(visible){
	      int i,len = children.size();
	      for(i=0;i<len;i++)children.get(i).updateVertexPosition(); 
	    }
	  }
	  
	  
	}
