package kosmos.displayList;

import kosmos.texture.TextureArea;

public class DisplayObject3D extends Object3D {
	
	public float _realRed;
	public float _realGreen;
	public float _realBlue;
	public float _realAlpha;
	
	//getter & setter
	public float redMulti;
	public float greenMulti;
	public float blueMulti;
	public float alpha;
	
	public Boolean visible;
	public TextureArea texture;
	  
	
	//must be used as getter only
	public float width;
	public float height;
	public float depth;
	
	
	
	
	
	protected boolean mouseIsOver;
	
	protected float minimalX;
    protected float minimalY;
    protected float maximalX;
    protected float maximalY;
  
    protected float boundMinX;
    protected float boundMaxX;
    protected float boundMinY;
    protected float boundMaxY;
    protected float boundMinZ;
    protected float boundMaxZ;
    protected long getWidthTime;
    protected long getHeightTime;
    protected long getDepthTime;
	
    
	DisplayObject3D(){
		super();
		_realRed = _realGreen = _realBlue = _realAlpha = redMulti = greenMulti = blueMulti = alpha = (float) 1.0;
		width = height = depth = 0.0f;
	    visible = true;
	    texture = null;
	}
	
	 void hideObject(){
	    if(visible == true){
	      visible = false;
	      
	      //int i,len = startTriangleId + nbTriangle;
	      //for(i=startTriangleId;i<len;i++) allTriangles[i].visible = visible;
	    } 
	  }
	 
	  void showObject(){
	    if(visible == false){
	      visible = true;
	      
	      //int i,len = startTriangleId + nbTriangle;
	      //for(i=startTriangleId;i<len;i++) allTriangles[i].visible = visible;
	    } 
	  }
	  
	  protected void setMouseIsOver(boolean b){
		  mouseIsOver = b;
		  if(mouseIsOver == true) dispatchEvent("ON_MOUSE_OVER");
		  else dispatchEvent("ON_MOUSE_OUT");
	  }
	  
	  public void changeTexture(TextureArea t){
		  dispatchEvent("ON_TEXTURE_CHANGE");
		  texture = t;
		  
		  //must be overrided -->> must update the UV in the array
	  }
	  
	  public void mousePressed(){
		  dispatchEvent("ON_MOUSE_PRESS");
	  }
	  public void mouseReleased(){
		  dispatchEvent("ON_MOUSE_RELEASE");
	  }
	  public void mouseClick(){
		  dispatchEvent("ON_MOUSE_CLICK");
	  }
	  
	  protected void setStage(Layer3D r){
	     super.setStage(r);
	     if(stage != null) dispatchEvent("ON_ADDED_TO_STAGE");
	     else dispatchEvent("ON_REMOVED_FROM_STAGE");
	     
	     updateWidth();
	     updateHeight();
	     
	     minimalX = -width/2;
	     minimalY = -height/2;
	     
	     //System.out.println(Math.abs(minimalX*2) + " : "+Math.abs(minimalY*2));
	     
	     maximalX = r.stageW - minimalX;
	     maximalY = r.stageH - minimalY;
	  }
	  protected void setParent(DisplayObject3D p){
	     parent = p;
	     if(parent != null) dispatchEvent("ON_ADDED");
	     else dispatchEvent("ON_REMOVED");
	  }
	  
	  
	  protected void updatePosition(){
		  super.updatePosition();
		  
		  
		  _realRed = parent._realRed * redMulti;;
		  _realGreen = parent._realGreen * greenMulti;
		  _realBlue = parent._realBlue * blueMulti;
		  _realAlpha = parent._realAlpha * alpha;
		  
	  }
	  
	  
	  public void ____applyColorTransform(DisplayObject3D o){
		  if(this != o ) {
			 
			  stage.applet.tint(_realRed,_realGreen,_realBlue,_realAlpha);
		  }
	  }
	  
	  
	  void updateWidth(){
		  
	  }
	  
	  void updateHeight(){
		  
	  }
	  
	  void getDepth(){
		  
	  }
}
