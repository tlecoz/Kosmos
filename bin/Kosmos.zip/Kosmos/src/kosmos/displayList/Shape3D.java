package kosmos.displayList;

import kosmos.texture.TextureArea;



public class Shape3D extends DisplayObject3D {
	  
	  
	//###### INTERNAL ######################
	  
	  protected int startVertexId;
	  protected int nbVertex;
	  
	  protected int startTriangleId;
	  protected int nbTriangle;
	  
	  protected float[] allVertexXYZ;
	  protected float[] allVertexUV;
	  protected float[] allTransformXYZ;
	  public TriangleObj[] allTriangles;
	  
	  
	  
	  
	  
	  private boolean _renderable;
	  
	  
	  
	 //##############################
	  
	  
	 
	  
	  
	 
	  
	  
	  
	  public Layer3D renderer;
	  
	 
	  
	  
	  
	  
	  protected Shape3D(){
	    _renderable = true;
	  }
	  
	  void hideObject(){
	    if(visible == true){
	      visible = false;
	      
	      int i,len = startTriangleId + nbTriangle;
	      for(i=startTriangleId;i<len;i++) allTriangles[i].visible = visible;
	    } 
	  }
	 
	  void showObject(){
	    if(visible == false){
	      visible = true;
	      
	      int i,len = startTriangleId + nbTriangle;
	      for(i=startTriangleId;i<len;i++) allTriangles[i].visible = visible;
	    } 
	  }
	  
	  protected Shape3D(Layer3D r,TextureArea textureArea,int numTriangle){
	     visible = _renderable = true;
	     mouseIsOver = false;
	     
	     renderer = r;
	     nbTriangle = numTriangle;
	     startTriangleId = renderer.nbTriangle;
	     
	     
	     texture = textureArea;
	     allVertexXYZ = renderer.allVertexXYZ;
	     allVertexUV = renderer.allVertexUV;
	     allTransformXYZ = renderer.allTransformXYZ; 
	     allTriangles = renderer.allTriangles;
	     
	     getWidthTime = getHeightTime = getDepthTime = 0;
	  }
	  
	  
	  
	  
	  boolean renderable(){
		  return _renderable;
	  }
	  
	  
	  
	  void updateWidth(){
		  
		  long time = System.currentTimeMillis();
		  if(time - getWidthTime > 0) {
		  
			  boundMinX = 100000.0f;
			  boundMaxX = -100000.0f;
			  
			  int i,start = startVertexId * 3, len = (startVertexId + nbVertex) * 3;
			  float n;
			  for(i=start;i<len;i+=3){
				  n = allTransformXYZ[i];
				  if(n < boundMinX) boundMinX = n;
				  if(n > boundMaxX) boundMaxX = n;
			  }
			  getWidthTime = time;
		  }
		  width = boundMaxX-boundMinX;
	  }
	  
	  void updateHeight(){
		  long time = System.currentTimeMillis();
		  if(time - getHeightTime > 0) {
			  
			  boundMinY = 100000.0f;
			  boundMaxY = -100000.0f;
			  
			  int i,start = (startVertexId * 3 + 1), len = (startVertexId + nbVertex) * 3;
			  float n;
			  for(i=start;i<len;i+=3){
				  n = allTransformXYZ[i];
				  if(n < boundMinY) boundMinY = n;
				  if(n > boundMaxY) boundMaxY = n;
			  }
			  getHeightTime = time;
		  }
		  
		  height = boundMaxY-boundMinY;
	  }
	  
	  void getDepth(){
		  long time = System.currentTimeMillis();
		  if(time - getDepthTime > 0) {
			  boundMinZ = 100000.0f;
			  boundMaxZ = -100000.0f;
			  
			  int i,start = (startVertexId * 3 + 2), len = (startVertexId + nbVertex) * 3;
			  float n;
			  for(i=start;i<len;i+=3){
				  n = allTransformXYZ[i];
				  if(n < boundMinZ) boundMinZ = n;
				  if(n > boundMaxZ) boundMaxZ = n;
			  }
			  getDepthTime = time;
		  }
		  
		  depth = boundMaxZ-boundMinZ;
	  }
	  
	  
	  
	  
	  
	 
	  
	  
	  void updateVertexPosition(){
	    
	    if(visible){
	      
	      float px,py,pz,xy,xz,yz,yx,zx,zy;
	      float ppx,ppy,ppz;
	      
	      float psx = (float) Math.sin(parent.rotationX);
	      float pcx = (float) Math.cos(parent.rotationX);
	      
	      float psy = (float) Math.sin(parent.rotationY);
	      float pcy = (float) Math.cos(parent.rotationY);
	      
	      float psz = (float) Math.sin(parent.rotationZ);
	      float pcz = (float) Math.cos(parent.rotationZ);
	      
	      ppx = x;
	      ppy = y;
	      ppz = z;
	      
	      
	      
	      float scaleFactor;
	      
	      //ROTATION X
	      xy = pcx * ppy - psx * ppz;
	      xz = psx * ppy + pcx * ppz;

	      //ROTATION Y
	      yz = pcy * xz - psy * ppx;
	      yx = psy * xz + pcy * ppx;

	      //ROTATION Z
	      zx = pcz*yx - psz*xy;
	      zy = psz*yx + pcz*xy;
	      
	      
	      scaleFactor = focalLength/(focalLength -parent._realZ+ yz);
	        
	      ppx = zx * scaleFactor;
	      ppy = zy * scaleFactor;
	      ppz = yz ;
	      
	      
	      
	      ppx += parent._realX;
	      ppy += parent._realY;
	      ppz += parent._realZ;
	      
	      
	      
	      
	      
	      //ROTATIONS
	      float sx = (float) Math.sin(rotationX);
	      float cx = (float) Math.cos(rotationX);
	      float sy = (float) Math.sin(rotationY);
	      float cy = (float) Math.cos(rotationY);
	      float sz = (float) Math.sin(rotationZ);
	      float cz = (float) Math.cos(rotationZ);
	      
	      
	      
	      
	      
	      float oldFactor = scaleFactor;
	      
	      int i,i3,i2,i33,k = 0,len = startVertexId + nbVertex;
	      for(i = startVertexId;i<len;i++){
	        
	        i3 = i*3;
	        
	        px = allVertexXYZ[i3] * _realSX;
	        py = allVertexXYZ[i3+1] * _realSY;
	        pz = allVertexXYZ[i3+2] * _realSZ;
	        
	        
	        //ROTATION X
	        xy = cx * py - sx * pz;
	        xz = sx * py + cx * pz;
	  
	        //ROTATION Y
	        yz = cy * xz - sy * px;
	        yx = sy * xz + cy * px;
	  
	        //ROTATION Z
	        zx = cz*yx - sz*xy;
	        zy = sz*yx + cz*xy;
	        
	        
	        scaleFactor = ((focalLength)/(focalLength + yz)) * oldFactor;
	        
	        px = zx * scaleFactor;
	        py = zy * scaleFactor; 
	        pz = yz ;
	        
	        px += ppx;
	        py += ppy;
	        pz += ppz;
	        
	        
	       
	        
	        allTransformXYZ[i3] = _realX = px;// + x + px ;
	        allTransformXYZ[i3+1] =  _realY = py;// + y + py;
	        allTransformXYZ[i3+2] =   _realZ = pz;// + z + pz;
	        
	        _renderable = pz < minimalZ && px >= minimalX && px <= maximalX && py >= minimalY && py <= maximalY && alpha >= 0.01;
	        //System.out.println(""+pz+" : "+minimalZ);
	        
	      }
	    }
	     
	  }
	  
	}
