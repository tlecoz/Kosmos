package kosmos.displayList;

import kosmos.utils.AppletInstance;
import kosmos.utils.GraphicUtils;
import processing.core.PApplet;
import processing.core.PImage;

public class MultiLayerManager {
	
	private Layer3D[] layers;
	private int nbLayer;
	
	private PApplet applet;
	private float screenW;
	private float screenH;
	
	private boolean useMouseEvent;
	public Shape3D objectUnderMouse;
	
	public MultiLayerManager(PApplet appletObj,float screenWidth,float screenHeight,int nbLayerMax){
		applet = appletObj;
		screenW = screenWidth;
		screenH = screenHeight;
		layers = new Layer3D[nbLayerMax];
		nbLayer = 0;
		useMouseEvent = false;
		objectUnderMouse = null;
		new GraphicUtils(applet);
		new AppletInstance(applet);
	}
	
	public MultiLayerManager(PApplet appletObj,int nbLayerMax){
		applet = appletObj;
		screenW = applet.width;
		screenH = applet.height;
		layers = new Layer3D[nbLayerMax];
		nbLayer = 0;
		new GraphicUtils(applet);
	}
	
	/*
	public Layer3D createLayer(String layerName,PImage texture,int nbTriangleMax,boolean enableMouseEvent){
		Layer3D layer = new Layer3D(applet,screenW,screenH,texture,nbTriangleMax,useMouseEvent);
		layers[nbLayer++] = layer;
		layer.name = layerName;
		if(enableMouseEvent) useMouseEvent = true;
		return layer;
	}
	
	public Layer3D createLayer(PImage texture,int nbTriangleMax,boolean enableMouseEvent){
		Layer3D layer = new Layer3D(applet,screenW,screenH,texture,nbTriangleMax,enableMouseEvent);
		layer.name = "Layer3D_"+nbLayer;
		layers[nbLayer++] = layer;
		if(enableMouseEvent) useMouseEvent = true;
		return layer;
	}
	public Layer3D createLayer(PImage texture,boolean enableMouseEvent){
		Layer3D layer = new Layer3D(applet,screenW,screenH,texture,5000,enableMouseEvent);
		layer.name = "Layer3D_"+nbLayer;
		layers[nbLayer++] = layer;
		if(enableMouseEvent) useMouseEvent = true;
		return layer;
	}
	public Layer3D createLayer(PImage texture){
		useMouseEvent = true;
		Layer3D layer = new Layer3D(applet,screenW,screenH,texture,5000,useMouseEvent);
		layer.name = "Layer3D_"+nbLayer;
		layers[nbLayer++] = layer;
		return layer;
	}
	*/
	public Layer3D createLayer(String layerName,int textureW,int textureH,int nbTriangleMax,boolean enableMouseEvent){
		Layer3D layer = new Layer3D(applet,screenW,screenH,textureW,textureH,nbTriangleMax,useMouseEvent);
		layers[nbLayer++] = layer;
		layer.name = layerName;
		if(enableMouseEvent) useMouseEvent = true;
		return layer;
	}
	
	public Layer3D createLayer(int textureW,int textureH,int nbTriangleMax,boolean enableMouseEvent){
		Layer3D layer = new Layer3D(applet,screenW,screenH,textureW,textureH,nbTriangleMax,enableMouseEvent);
		layer.name = "Layer3D_"+nbLayer;
		layers[nbLayer++] = layer;
		if(enableMouseEvent) useMouseEvent = true;
		return layer;
	}
	public Layer3D createLayer(int textureW,int textureH,boolean enableMouseEvent){
		Layer3D layer = new Layer3D(applet,screenW,screenH,textureW,textureH,5000,enableMouseEvent);
		layer.name = "Layer3D_"+nbLayer;
		layers[nbLayer++] = layer;
		if(enableMouseEvent) useMouseEvent = true;
		return layer;
	}
	public Layer3D createLayer(int textureW,int textureH){
		useMouseEvent = true;
		Layer3D layer = new Layer3D(applet,screenW,screenH,textureW,textureH,5000,useMouseEvent);
		layer.name = "Layer3D_"+nbLayer;
		layers[nbLayer++] = layer;
		return layer;
	}
	public Layer3D createLayer(){
		useMouseEvent = true;
		Layer3D layer = new Layer3D(applet,screenW,screenH,2048,2048,5000,useMouseEvent);
		layer.name = "Layer3D_"+nbLayer;
		layers[nbLayer++] = layer;
		return layer;
	}
	
	
	public void reverseLayers(){
		Layer3D[] temp = new Layer3D[layers.length];
		int i,k=0;
		for(i=nbLayer-1;i>-1;i--)temp[k++] = layers[i];
	}
	
	
	public void update(){
		
		applet.colorMode(applet.RGB, 1.0f);
		
		int i;
		if(useMouseEvent == false) for(i=nbLayer-1;i>-1;i--) layers[i].update(false);
		else {
			boolean checkMouseEvent = true;
			for(i=nbLayer-1;i>-1;i--){
				if(checkMouseEvent){
					objectUnderMouse = layers[i].update(checkMouseEvent);
					if(objectUnderMouse != null) checkMouseEvent = false;
				}else{
					layers[i].update(false);
				}
			}
		}
	}
	
	
}
